# Release Notes

## 1.1.1
- Fixed a bug where network aliases support was nonfunctional.

## 1.1.0
- Added support for network aliases - multiple names for the same container.

## 1.0.0
- Initial release